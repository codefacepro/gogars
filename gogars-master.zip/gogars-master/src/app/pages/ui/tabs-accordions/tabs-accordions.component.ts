import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-tabs-accordions',
  templateUrl: './tabs-accordions.component.html',
  styleUrls: ['./tabs-accordions.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class TabsAccordionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
