import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-buttons',
  templateUrl: './buttons.component.html',
  styleUrls: ['./buttons.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ButtonsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
