import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-list-group',
  templateUrl: './list-group.component.html',
  styleUrls: ['./list-group.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ListGroupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
