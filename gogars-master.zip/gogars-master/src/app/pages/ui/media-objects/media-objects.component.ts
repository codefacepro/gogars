import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-media-objects',
  templateUrl: './media-objects.component.html',
  encapsulation: ViewEncapsulation.None
})
export class MediaObjectsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
