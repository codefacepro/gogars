import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-basic-tables',
  templateUrl: './basic-tables.component.html',
  encapsulation: ViewEncapsulation.None
})
export class BasicTablesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
