export class SideChat {
    constructor(public image: string,
                public author: string,
                public authorStatus: string,
                public text: string,
                public date: Date,
                public side: string) { }
} 