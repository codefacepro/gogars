import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
    selector: 'app-applications',
    encapsulation: ViewEncapsulation.None,
    styleUrls: ['./applications.component.scss'],
    templateUrl: './applications.component.html'
})
export class ApplicationsComponent implements OnInit { 

    ngOnInit() {

    }
}